package model;

import java.awt.Color;

import javax.swing.JFrame;

public class Main {
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		frame.setSize(900, 1000);
		frame.setTitle("Box");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		GamePanel gp = new GamePanel();

		frame.add(gp);
		frame.setVisible(true);
		gp.startGameThread();
	}
}
