package model;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;

import entity.Bullets;
import entity.Enemy;
import entity.Player;
import map.Map;

public class GamePanel extends JPanel implements Runnable{

	private static final long serialVersionUID = 1L;
	
	Map map;
//	GamePanel gp;
	Thread gameThread;
	Player player;
	public int numEn = 30;
	public int FPS = 60;
	public int width = 900;
	public int height = 1000;

	KeyHandler ke;
	List<Enemy> enemies;
	// Test spawning enemies
	

	
	public GamePanel() {
		this.setBackground(Color.black);
		this.setPreferredSize(new Dimension(width, height));
		this.setDoubleBuffered(true);

		enemies = new ArrayList<>();
		for(int i = 0; i < numEn; i++) {
			// x is random, y is random [enemies at random locations]
			enemies.add(new Enemy((new Random().nextInt(1450)) - 1500/2 
					, (new Random().nextInt(1450) - 1500/2)));
		}
		ke = new KeyHandler();
		map = new Map();
		player = new Player(ke);
		
		setPlayerSpeed();
		setEnemySpeed();
		this.addKeyListener(ke);
		this.setFocusable(true);
	}
	public void setEnemySpeed() {
		for(Enemy enemy: enemies){
			enemy.speed = (enemy.speed)*((double)60/FPS);
		}
	}

	
	// Can scale FPS, while maintaining speed.
	public void setPlayerSpeed() {
		player.speed = (player.speed)*((double)60/FPS);
	}
	
	public void paintComponent(Graphics g) {
		
			if (ke.upPressed) {
				player.y -= player.speed;
				map.map1.y += player.speed;
				for(Enemy enemy: enemies) {
					enemy.rec.y += player.speed;
					for(Bullets bullet: enemy.bullets) {
						bullet.bulletY += player.speed;
					}
				}
			}
			if (ke.downPressed) {
				player.y += player.speed;
				map.map1.y -= player.speed;
				for(Enemy enemy: enemies) {
					enemy.rec.y -= player.speed;
					for(Bullets bullet: enemy.bullets) {
						bullet.bulletY -= player.speed;
					}
				}
			}
			if (ke.leftPressed) {
				player.x -= player.speed;
				map.map1.x += player.speed;
				for(Enemy enemy: enemies) {
					enemy.rec.x += player.speed;
					for(Bullets bullet: enemy.bullets) {
						bullet.bulletX += player.speed;
					}
				}
			}
			if (ke.rightPressed) {
				player.x += player.speed;
				map.map1.x -= player.speed;
				for(Enemy enemy: enemies) {
					enemy.rec.x -= player.speed;
					for(Bullets bullet: enemy.bullets) {
						bullet.bulletX -= player.speed;
					}
				}
			}
		
		
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D) g;
		
		map.draw(g2);
		
		for(Enemy enemy : enemies) {
			enemy.draw(g2);
		}
		player.update();
		player.draw(g2);
		g2.dispose();
		
	}
	
	public void startGameThread() {
		 gameThread = new Thread(this);
		 gameThread.start();
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		while(gameThread != null) {
			
			currentTime = System.nanoTime();
			delta += (currentTime - lastTime) / drawInterval;
			lastTime = currentTime;
			
			if (delta >= 1) {
				for(Enemy enemy : enemies) {
					enemy.update(player);
				}
				repaint();
				delta --;
			}
		}
		
	}	
}
