package model;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import entity.Player;

public class KeyHandler implements KeyListener{
	
	public boolean upPressed, downPressed, leftPressed, rightPressed;
	
	Player player;
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		
		if (e.getKeyCode() == KeyEvent.VK_W) {
			upPressed = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_S) {
			downPressed = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_A) {
			leftPressed = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_D) {
			rightPressed = true;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_W) {
			upPressed = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_S) {
			downPressed = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_A) {
			leftPressed = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_D) {
			rightPressed = false;
		}
	}
}