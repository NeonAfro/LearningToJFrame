/**
 * 
 */
/**
 * @author donghwanchung
 *
 */
module LearningToJFrame {
	requires java.desktop;
}