package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Bullets extends Entity{
	
	public Rectangle rec;
	int size = 10;
	public double speedX = 0;
	public double speedY = 0;
	public double bulletX, bulletY;
	int damage = 5;
	boolean collided = false;
	boolean fired = false;
	// 0, 1, 2
	int whichBullet;
	
	public Bullets(int x, int y, int i) {
		rec = new Rectangle(x, y, size, size);
		bulletX = (double) x;
		bulletY = (double) y;
		whichBullet = i;
	}
	public void update(Player player) {
		
		// left, right, up, down
		if ((!(rec.x + 10 < player.rec.x || rec.x > player.rec.x + 25)
				&& !(rec.y + 10 < player.rec.y || rec.y > player.rec.y + 25))) {
			player.takeDamage(damage);
			collided = true;
		}
		
		// set speed according to player position.
		if(speedX == 0 && speedY == 0) {
			double result = 0;
			result = Math.pow(rec.x+size/2 - (player.rec.x+(player.size/2)), 2) 
					+ Math.pow(rec.y+size/2 - (player.rec.y+(player.size/2)), 2);
			result = result/25;
			speedX = Math.sqrt(Math.pow(rec.x+size/2 - 
					(player.rec.x+(player.size/2)), 2)/result);
			speedY = Math.sqrt(Math.pow(rec.y+size/2 -
					(player.rec.y+(player.size/2)), 2)/result);
//			System.out.println(speedX+ " " + speedY + " " 
//					+ Math.sqrt((Math.pow(speedX, 2))
//							+(Math.pow(speedY, 2))));
			
		}
		// fix, change so the the bullet shoots at the player
			if (!fired) {
				
				if(rec.x < player.rec.x) {
					bulletX += speedX;
					rec.x = (int) Math.round(bulletX);
				} else {
					speedX = -speedX;
					bulletX += speedX;
					rec.x = (int) Math.round(bulletX);
				}
				
				
				if(rec.y < player.rec.x) {
					bulletY += speedY;
					rec.y = (int) Math.round(bulletY);
				} else {
					speedY = -speedY;
					bulletY += speedY;
					rec.y = (int) Math.round(bulletY);
				}
				// different bullet spray needs work
//				if(whichBullet == 1) {
//					speedX = -speedX;
//				}
//				if(whichBullet == 2) {
//					speedY = -speedY;
//				}
			}
			bulletX += speedX;
			bulletY += speedY;
			rec.x = (int) Math.round(bulletX);
			rec.y = (int) Math.round(bulletY);
		fired = true;
	}
	public void draw(Graphics2D gp) {
		gp.setPaintMode();
		gp.setColor(Color.green);
		gp.fill(rec);
	}
}
