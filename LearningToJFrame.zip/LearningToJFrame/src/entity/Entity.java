package entity;

public class Entity {
	public int x, y;
	boolean collision;
}
