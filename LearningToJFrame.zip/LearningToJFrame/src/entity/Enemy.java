package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Enemy extends Entity{
	
	public Rectangle rec;
	int DEFAULT_SIZE = 50;
	public double speed = 5;
	public List<Bullets> bullets;
	int bulletCount;
	
	
	public Enemy(int x, int y) {
		rec = new Rectangle(x, y, DEFAULT_SIZE, DEFAULT_SIZE);
		bullets = new ArrayList<>();
	}
	
	public void update(Player player) {
//		if (player.rec.x - rec.x > 100 || rec.x - player.rec.x > 100) {
//			if (player.rec.x > rec.x) {
//				rec.x += speed;
//			}
//			if (player.rec.x < rec.x) {
//				rec.x -= speed;
//			}
//		}
//		if (player.rec.y - rec.y > 100 || rec.y - player.rec.y > 100) {
//			if (player.rec.y > rec.y) {
//				rec.y += speed;
//			}
//			if (player.rec.y < rec.y) {
//				rec.y -= speed;
//			}
//		}
//		
		int index = 0;
		int remove = 0;
		boolean collided = false;
		if (!bullets.isEmpty()) {
			for(Bullets bullet: bullets) {
				
				bullet.update(player);
				
				if(bullet.collided) {
					collided = true;
				}
				
				index++;
			}
			if (collided) {
				bullets.remove(remove);
				collided = false;
			}
		}
		if(bulletCount == 240) {
			bullets.clear();
			bulletCount = 0;
		}
		if (bulletCount % 120 == 0) {
			
//			for(int i = 0; i < 3; i++) {
				bullets.add(new Bullets(rec.x+25, rec.y+25, 1));
					
//			}
		}
		
		bulletCount++;
	}
	
	public void draw(Graphics2D gp) {
		
		gp.setPaintMode();
		
		gp.setColor(Color.black);
		
		gp.fill(rec);
		for(Bullets bullet: bullets) {
			bullet.draw(gp);
		}
	}
}
