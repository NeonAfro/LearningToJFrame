package map;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Map {
	
	public Rectangle map1;
	public int worldX = 1500;
	public int worldY = 1500;
	
	
	public Map() {
		map1 = new Rectangle(-worldX/2, -worldY/2, worldX, worldY);
	}
	public void draw(Graphics2D gp) {
		gp.setPaintMode();
		gp.setColor(Color.DARK_GRAY);
		gp.fill(map1);
//		System.out.println("worldX: "+ map1.x+" || worldY: "+map1.y);
	}
}
